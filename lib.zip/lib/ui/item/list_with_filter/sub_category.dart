//import 'package:flutter/material.dart';
//class SubCategory extends StatefulWidget {
//  @override
//  _SubCategoryState createState() => _SubCategoryState();
//}
//
//class _SubCategoryState extends State<SubCategory> {
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      appBar: AppBar(
//        title: Text('dfdsfd '),
//      ),
//      body: Container(
//        color: Colors.lightGreen,
//        child: Text('helo moto'),
//      ),
//    );
//  }
//}
